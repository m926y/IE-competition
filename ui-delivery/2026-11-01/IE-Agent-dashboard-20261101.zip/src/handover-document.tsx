import { useRef, useState } from 'react';
import type { Entry, Report } from './handover';

const localTime=(s:string)=>new Date(s).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false});
const kindName:Record<string,string>={risk:'风险案卷',alert:'告警档案',training:'培训验收',chat:'沟通回复',followup:'处置回访',review:'评分异议'};
export function HandoverDocument({report,onOpen}:{report:Report;onOpen:(item:Entry)=>void}) {
  const paper=useRef<HTMLElement>(null),[busy,setBusy]=useState(false),[error,setError]=useState('');
  const counts=report.snapshot.counts,example=report.trigger==='example';
  const metrics=[['新增案卷','new_cases'],['已关闭案卷','closed_cases'],['培训待验收','pending_training_review'],['待回复会话','pending_chats']];
  async function download(format:'png'|'pdf') {
    if(!paper.current)return;setBusy(true);setError('');
    try {
      await document.fonts.ready;
      const {toCanvas}=await import('html-to-image');
      const canvas=await toCanvas(paper.current,{pixelRatio:2,backgroundColor:'#ffffff',filter:node=>!(node instanceof HTMLElement&&node.dataset.noExport==='true')});
      const name=report.report_date+'-安全交接单';
      const save=(blob:Blob,filename:string)=>{const url=URL.createObjectURL(blob),link=document.createElement('a');link.download=filename;link.href=url;document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);};
      if(format==='png'){const blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(value=>value?resolve(value):reject(new Error('图片生成失败')),'image/png'));save(blob,name+'.png');}
      else {const {jsPDF}=await import('jspdf');const pdf=new jsPDF({orientation:'portrait',unit:'mm',format:'a4'}),pageHeight=Math.floor(canvas.width*277/190);for(let y=0;y<canvas.height;y+=pageHeight){if(y)pdf.addPage();const part=document.createElement('canvas');part.width=canvas.width;part.height=Math.min(pageHeight,canvas.height-y);part.getContext('2d')!.drawImage(canvas,0,y,canvas.width,part.height,0,0,part.width,part.height);pdf.addImage(part.toDataURL('image/png'),'PNG',10,10,190,part.height*190/part.width);}save(pdf.output('blob'),name+'.pdf');}
    }catch{setError('导出未完成，请重试。')}finally{setBusy(false);}
  }
  return <><div className="handover-document-tools"><span className="tag">{example?'演示记录':report.id==='preview'?'今日预览 · 未发送':report.status==='accepted'?'已接收':report.status==='pending'?'待接收':'待指定接班人'}</span><div><button className="btn" disabled={busy} onClick={()=>void download('png')}>{busy?'正在导出…':'保存图片'}</button><button className="btn primary" disabled={busy} onClick={()=>void download('pdf')}>下载 PDF</button></div></div>{error&&<p role="alert" className="alert danger">{error}</p>}<article ref={paper} className="handover-paper">
    <header className="handover-paper-header"><div className="handover-paper-brand"><span>行安</span><span>运营安全管理</span></div><div className="handover-paper-number">{example?'演示样例':report.id==='preview'?'当日交接预览':'交接归档'} · {report.report_date.replaceAll('-','')}</div></header>
    <div className="handover-paper-title"><span>SHIFT HANDOVER</span><h2>车队安全交接单</h2><p>{report.report_date} · 工作交接与重点事项</p></div>
    <dl className="handover-paper-meta"><div><dt>交班人</dt><dd>{report.owner_name}</dd></div><div><dt>{report.id==='preview'?'拟接班人':'接班人'}</dt><dd>{report.recipient_name||'待指定'}</dd></div><div><dt>统计截止</dt><dd>{localTime(report.cutoff_at)}</dd></div><div><dt>记录时间</dt><dd>{localTime(report.captured_at)}</dd></div></dl>
    <section className="paper-section"><h3><span>01</span> 本班工作概况</h3><div className="paper-metrics">{metrics.map(([label,key])=><div key={key}><span>{label}</span><strong>{counts[key]||0}<small> 项</small></strong></div>)}</div><div className="paper-summary"><p>截至交接时点，本班已完成 <strong>【{counts.closed_cases||0} 项】</strong> 案卷关闭、<strong>【{counts.training_reviewed||0} 项】</strong> 培训验收。</p><p>需继续跟进风险 <strong>【{counts.pending_risks||0} 项】</strong>，其中红色风险 <strong>【{counts.pending_red||0} 项】</strong>；待学习培训 <strong>【{counts.pending_training_learning||0} 项】</strong>。</p></div></section>
    <section className="paper-section"><h3><span>02</span> 接班重点事项</h3>{!report.summary.priorities.length?<div className="paper-empty">本次无未完成事项移交。接班后按日常安全巡查流程开展工作。</div>:<ol className="paper-priorities">{report.summary.priorities.map((p,i)=><li key={i}><span>{String(i+1).padStart(2,'0')}</span><div><p>{p.text}</p>{!example&&<div className="paper-evidence" data-no-export="true">{p.refs.map(ref=>{const item=report.snapshot.items.find(x=>x.id===ref);return item?<button className="btn" key={ref} onClick={()=>onOpen(item)}>查看 {item.vehicle} · {item.title}</button>:null})}</div>}</div></li>)}</ol>}</section>
    <section className="paper-section"><h3><span>03</span> 待办移交清单 <small>{report.snapshot.items.length} 项</small></h3>{!report.snapshot.items.length?<p className="paper-empty">无待办移交。</p>:<div className="paper-item-grid">{report.snapshot.items.map(item=><div className="paper-item" key={item.id}><span>{kindName[item.kind]||'待办事项'}{item.is_replay?' · 历史回放':''}</span><h4>{item.vehicle} · {item.title}</h4>{item.last_message&&<p>司机说明：{item.last_message.content}</p>}{item.due_at&&<small>截止 {localTime(item.due_at)}</small>}{!example&&<button data-no-export="true" className="btn" onClick={()=>onOpen(item)}>{item.kind==='chat'?'打开会话':'查看与处理'}</button>}</div>)}</div>}</section>
    {report.notes.length>0&&<section className="paper-section"><h3><span>04</span> 补充说明</h3>{report.notes.map(n=><p key={n.id}><b>{n.author_name}</b> · {n.content}</p>)}</section>}
    <footer className="paper-signatures"><div><span>交班确认</span><b>{report.owner_name}</b></div><div><span>接班确认</span><b>{report.accepted_at?report.recipient_name:'待接收确认'}</b></div></footer><p className="paper-footnote">行安 · 安全交接留档{example?' · 演示样例，不计入业务统计':` · 评分数据截至 ${report.snapshot.score_reference.latest_date||'未取得'}`}</p>
  </article></>;
}

export function handoverExamples():Report[] {
  return ['2026-10-30','2026-10-28','2026-10-26'].map((date,index)=>{
    const items:Entry[]=[{id:'example-review-'+index,kind:'review',title:'评分依据待核对',vehicle:'车辆152',status:'checking',is_replay:false},{id:'example-training-'+index,kind:'training',title:'学习反馈待复核',vehicle:'车辆77',status:'submitted',is_replay:false}];
    return {id:'example-'+date,owner_id:'example-owner',owner_name:'安全管理岗',recipient_id:null,recipient_name:'接班安全岗',report_date:date,status:'accepted',ai_status:'disabled',captured_at:date+'T10:00:00Z',cutoff_at:date+'T10:00:00Z',accepted_at:date+'T10:05:00Z',accepted_note:'',trigger:'example',counts:{},summary:{overview:'',priorities:[{text:'优先核对车辆152的评分依据，保留复核结论后回复申请人。',refs:[items[0].id]},{text:'检查车辆77的学习反馈及行动计划，完成后记录验收意见。',refs:[items[1].id]}]},snapshot:{counts:{new_cases:3+index,closed_cases:2+index,pending_training_review:1,pending_chats:0,pending_risks:1,pending_red:0,training_reviewed:2,pending_training_learning:1},items,limitations:[],chat_total:0,chat:[],personal_actions:{},score_reference:{latest_date:'2026-07-31',vehicle_count:500,d_count:50,low_confidence:2}},notes:[]};
  });
}
